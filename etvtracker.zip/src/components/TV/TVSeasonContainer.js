import React from 'react';
import { Collapse, Table, Checkbox } from 'antd';
import * as css from './TVSeasonStyle';

import TVSeasonDetail from './TVSeasonDetail';

const columns = [{
  title: '#',
  dataIndex: 'num',
  key: 'num',
}, {
  title: 'Name',
  dataIndex: 'name',
  key: 'name',
}, {
  title: 'Air Date',
  dataIndex: 'airDate',
  key: 'airDate',
}, {
  title: 'D',
  dataIndex: 'downloaded',
  key: 'downloaded',
  onHeaderCell: (column) => {
    return {
      onClick: () => {
        console.log('onClick', column);
      }
    };
  },
  render: () => <Checkbox onChange={(e) => console.log('D check', e.target.checked)}></Checkbox>
}, {
  title: 'W',
  dataIndex: 'watched',
  key: 'watched',
  render: () => <Checkbox onChange={(e) => console.log('W check', e.target.checked)}></Checkbox>
}];


const TVSeasonContainer = (props) => {
  const Panel = Collapse.Panel;
  if (!props.seasonData) {
    return null;
  }
  return (
    <Collapse accordion className={css.seasonWrapper}>
      {props.seasonData.map(season => {
        let dataSource = season.episodes.map(episode => ({
            key: episode.id,
            num: episode.number,
            name: episode.name,
            airDate: episode.airDate,
            downloaded: '',
            watched: ''
          }));
          return (
              <Panel header={season.name} key={season.id} style={{ padding: "0px"}}>
                <Table 
                  columns={columns} 
                  dataSource={dataSource} 
                  pagination={false}
                  indentSize={0}
                />
              </Panel>
          );
        })}
    </Collapse>
  );
};

export default TVSeasonContainer;

// <Panel header={season.name} key={season.id}>
// <TVSeasonDetail episodes={season.episodes} />
// </Panel>