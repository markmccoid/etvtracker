import React from 'react';
import { Button } from 'antd';
import { withRouter } from 'react-router-dom';


const TVAddItem = (props) => {
  const addTVShow = () => {
    const showId = props.show.id;
    props.startAddTVShow(showId)
      .then(() => props.history.push(`/tv/detail/${showId}`));
  }
  return (
    <div style={{margin: "5px", padding: "5px", border: "1px solid black"}}>
      <img alt={props.show.name} src={props.show.backdropURL} />
      {props.show.name}
      <Button 
        type="primary" 
        icon="plus"
        onClick={addTVShow}
      >Add</Button>
    </div>
  )
}

export default withRouter(TVAddItem);