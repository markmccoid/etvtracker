import React from 'react';
import { Button } from 'antd';
import * as css from './style';
import swal from 'sweetalert2';


const TVDetail = (props) => {
  const onDeleteShow = () => {
    //Delete alert
    swal({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      //html: `<img height="200" src=${props.showData.posterPath} />`,
      imageUrl: props.showData.posterPath,
      imageHeight: 200,
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        props.routeToTV();
        props.startDeleteTVShow(props.showData.showId)
          .then(() => {
            swal(
              'Deleted!',
              'Your file has been deleted.',
              'success'
            );
          }
        )
      }
    });
  }
  if (!props.showData.showId) {
    return null;
  }
  return (
    <div className={css.wrapper}>
      <div className={css.titleContainer}>
        <div className={css.title}>
          {props.showData.name}
        </div>
      </div>
      <div className={css.showContainer}>
        <div className={css.imageContainer}>
          <img className={css.poster} height="300" src={props.showData.posterPath} />
          <div className={css.buttonContainer}>
            <Button icon="delete" type="danger" onClick={onDeleteShow}>Delete</Button>
          </div>
        </div>
        <div className={css.summaryContainer}>
          <div className={css.showDetsContainer}>
            <div>
              <div className={css.showDetsTitle}>Status</div>
              <div className={css.showDetsDetail}>{props.showData.status}</div>
            </div>
            <div style={{borderRight: "1px solid #BDBDBD"}}></div>
            <div>
              <div className={css.showDetsTitle}>First Air Date</div>
              <div className={css.showDetsDetail}>{props.showData.firstAirDate}</div>
            </div>
            <div style={{borderRight: "1px solid #BDBDBD"}}></div>
            <div>
              <div className={css.showDetsTitle}>Last Air Date</div>
              <div className={css.showDetsDetail}>{props.showData.lastAirDate}</div>
            </div>
            <div style={{borderRight: "1px solid #BDBDBD"}}></div>
            <div>
              <div className={css.showDetsTitle}>Seasons</div>
              <div className={css.showDetsDetail}>{props.showData.totalSeasons}</div>
            </div>
            <div style={{borderRight: "1px solid #BDBDBD"}}></div>
            <div>
              <div className={css.showDetsTitle}>Episodes</div>
              <div className={css.showDetsDetail}>{props.showData.totalEpisodes}</div>
            </div>
          </div>
          <div className={css.overview}>
            <div className={css.summaryTitle}>Summary</div>
            <div className={css.summaryDetail}>{props.showData.overview}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TVDetail;