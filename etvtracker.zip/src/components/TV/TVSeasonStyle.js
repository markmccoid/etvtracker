import { css } from 'react-emotion';

export const seasonWrapper = css`
  max-width: 800px;
  margin-right: 10px;
`;

export const episodeWrapper = css`
  display: flex;
  flex-direction: row;
`;

export const header = css`
  font-weight: bold;
`;

export const numWidth = css`
  width: 50px;
`;
export const nameWidth = css`
  width: 200px;
`;
export const dateWidth = css`
  width: 75px;
`;
export const checkboxWidth = css`
  width: 50px;
`;