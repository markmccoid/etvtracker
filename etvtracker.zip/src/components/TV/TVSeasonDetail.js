import React from 'react';
import { Checkbox, Table  } from 'antd';
import { cx } from 'react-emotion';
import * as css from './TVSeasonStyle';

const columns = [{
  title: '#',
  dataIndex: 'num',
  key: 'num',
}, {
  title: 'Name',
  dataIndex: 'name',
  key: 'name',
}, {
  title: 'Air Date',
  dataIndex: 'airDate',
  key: 'airDate',
}, {
  title: 'D',
  dataIndex: 'downloaded',
  key: 'downloaded'
}, {
  title: 'W',
  dataIndex: 'watched',
  key: 'watched'
}];

const TVSeasonDetail = (props) => {
  return (
    <div>
      <div className={cx(css.episodeWrapper, css.header)}>
        <span className={css.numWidth}>#</span>
        <span className={css.nameWidth}>Name</span>
        <span className={css.dateWidth}>Air Date</span>
        <span className={css.checkboxWidth}>Downloaded</span>
        <span className={css.checkboxWidth}>Watched</span>
      </div>
      {props.episodes.map(episode => {
          return <div key={episode.id}>
            {episode.number}:{episode.name}:{episode.airDate}
            <Checkbox>Downloaded</Checkbox>
          </div>
        })
      }
    </div>
  );
};

export default TVSeasonDetail;