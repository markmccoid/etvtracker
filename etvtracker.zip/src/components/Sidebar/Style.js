import styled, { css } from 'react-emotion';
import { NavLink } from 'react-router-dom';

export const listContainer = css`
  margin-right: 1em;
`;

export const ListItemLink = styled(NavLink)`
  cursor: pointer;
  display: block;
  padding: 10px;
  border: 0;
  text-decoration: none;
  &:hover,:active {
    background: #EAEAEA;
  }
`;

export const listItemContainer = css`
  border-bottom: 1px solid #D9D9D9;
  border-right: 1px solid #D9D9D9;
  &:first-child {
    border-top: 1px solid #D9D9D9;
  }
`