import _ from 'lodash';
import moment from 'moment';

/**
 * Returns data need for display of shows in sidebar
 * 
 * @param {object} showData - Object of showData as formatted in redux store
 * @param string searchTerm - Search string to filter return data by (show.name)
 * @returns {string[]} Returns an array of objects with needed show data
 */
export const getSidebarData = (showData, searchTerm = '') => {
  // create an array of shows
  let showArray = [];
  //pass the filtered showData (by searchTerm) as the object for lodash's map function.
  showArray = _.map(_.filter(showData, (showObj) => showObj.name.toLowerCase().includes(searchTerm)),
                   (showObj) => ({ id: showObj.showId, name: showObj.name }));
  return showArray || [];
};

/**
 * Returns all TVShowData in array format
 * 
 * @returns {string[]} Returns an array of objects with all tvshowdata
 */
export const getAllShowData = (showData) => {
  // create an array of shows
  let showArray = [];
  showArray = _.map(showData, (showObj) => ({ ...showObj }));
  return showArray || [];
};

/**
 * Returns on object with show data for the showId passed in
 * 
 * @param {number} showId - Id of show to return data for
 * @param {object} showData - Object of objects of showData as formatted in redux store
 * @returns {object} Returns an object of show data
 */
export const getCurrentShow = (showId, showData) => {
  // Create an object holding the passed show Ids data
  let currShow = {};
  currShow = showData[showId];
  // Format moment dates
  if (currShow) {
    currShow = { ...currShow, 
      firstAirDate: moment(currShow.firstAirDate).format("MM/DD/YYYY"),
      lastAirDate: moment(currShow.lastAirDate).format("MM/DD/YYYY"),
    }
  }
  return currShow || {};
}

/**
 * Returns an object with the season data for the showId passed in
 * 
 * @param {number} showId - Id of show to return data for
 * @param {object} seasonData - Object of objects seasonData as formatted in redux store
 * @returns {object} Returns an object of season data
 */
export const getCurrentSeasons = (showId, seasonData) => {
  let currSeasons = {};
  currSeasons = seasonData[showId];
  // if no seasons, then return empty object
  if (!currSeasons) {
    return {};
  }
  // return an array of seasons with an array of episodes embedded
  let newCurrSeasons = [];
  Object.keys(currSeasons).forEach(seasonKey => {
    let workingSeason = currSeasons[seasonKey];
    // showId is a key and doesn't have season info in it, so skip it
    if (seasonKey !== 'showId') {
      let episodes = workingSeason.episodes;
      let updEpisodes = [];
      //Loop through episodes and format date
      Object.keys(episodes).forEach(episodeKey => {
        updEpisodes.push({ ...episodes[episodeKey], airDate: moment(episodes[episodeKey].airDate).format("MM/DD/YYYY") })
      });
      workingSeason.episodes = _.sortBy(updEpisodes, ['number']);
      // This is the old array based episodes
      // workingSeason.episodes = [ ...episodes.map(episode => 
      //     ({ ...episode, airDate: moment(episode.airDate).format("MM/DD/YYYY")}))];
      // Push the season on the array, formatting the season airdate as we do that.          
      newCurrSeasons.push({
        ...workingSeason, 
        airDate: moment(workingSeason.airDate).format("MM/DD/YYYY")
      });
    }
  });
  
  //console.log('selectors-seasons', newCurrSeasons)
  return _.sortBy(newCurrSeasons, ['number']);
  
}