import React from 'react';

class APIContainer extends React.Component {
  render() {
    return (
      <div><h3>API Container</h3></div>
    );
  }
}

export default APIContainer;