import React from 'react';
import { listItemContainer, ListItemLink } from './Style';

const SidebarItem = (props) => {
  let { provided, snapshot } = props;
  
  return (
    <div className={listItemContainer}
      ref={provided.innerRef}
      {...provided.draggableProps}
      {...provided.dragHandleProps}
    >
      <ListItemLink to={`/tv/detail/${props.showId}`}>
        {`${props.showName} - (${props.showId})`}
      </ListItemLink>
    </div>
  );
};

export default SidebarItem;

// const SidebarItem = (props) => {
//   return (
//     <ListItem>
//       <ListItemLink to={`/tv/${props.showId}`}>
//         {props.showId} <br/> {props.showName}
//       </ListItemLink>
//     </ListItem>
//   );
// };