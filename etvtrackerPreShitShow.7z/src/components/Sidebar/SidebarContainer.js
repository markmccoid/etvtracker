import React from 'react';
import { connect } from 'react-redux';
import { DragDropContext } from 'react-beautiful-dnd';

import SidebarList from './SidebarList';
import SidebarSearch from './SidebarSearch';

import { getSidebarData, setTvSearchterm } from '../../store/tvShows';

class SidebarContainer extends React.Component {
  state = {
    searchTerm: undefined
  }
  onDragEnd = (result) => {
    // dropped outside the list
    if (!result.destination) {
      return;
    }
    // console.log(`result.source.index: ${result.source.index}
    // result.destination.index: ${result.destination.index}`)
  }
  _onSearchTermUpdate = (searchTerm) => this.props.setTvSearchterm(searchTerm);

  render() {
    return (
      <div style={{display: "flex", flexDirection: "column"}}>
        <SidebarSearch history={this.props.history} onSearchTermUpdate={this._onSearchTermUpdate} searchTerm={this.props.searchTerm}/>
        <DragDropContext onDragEnd={this.onDragEnd}>
          <SidebarList sidebarData={this.props.sidebarData} />
        </DragDropContext>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    sidebarData: getSidebarData(state.TV.showData, state.TV.searchData.searchTerm),
    searchTerm: state.TV.searchData.searchTerm
  }
}
export default connect(mapStateToProps, { setTvSearchterm })(SidebarContainer);

// <React.Fragment>
// <SidebarList sidebarData={this.props.sidebarData} />
// </React.Fragment>