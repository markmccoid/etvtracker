import React from 'react';
import { connect } from 'react-redux';
import TVSeasonContainer from './Seasons/TVSeasonContainer';

import { 
  getCurrentShow, 
  getCurrentSeasons, 
  getUserEpisodeData,
  startDeleteTVShow, 
  updateDownloadedFlag,
  updateWatchedFlag } from '../../store/tvShows'

import TVDetail from './TVDetail';

class TVContainer extends React.Component {
  render() {
    return (<div>
      <TVDetail 
        showData={this.props.showData} 
        startDeleteTVShow={this.props.startDeleteTVShow}
        routeToTV={() => this.props.history.push("/tv")}
      />
      <TVSeasonContainer 
        seasonData={this.props.seasonData}
        showId={this.props.showData.showId}
        updateDownloadedFlag={this.props.updateDownloadedFlag}
        updateWatchedFlag={this.props.updateWatchedFlag}
      />
    </div>);
  }
}

const mapStateToProps = (state, props) => {
  return {
    showData: getCurrentShow(props.match.params.id, state.TV.showData),
    seasonData: getCurrentSeasons(props.match.params.id, state.TV.seasonData, state.TV.userData)
  }
}
export default connect(mapStateToProps, { startDeleteTVShow, updateDownloadedFlag, updateWatchedFlag })(TVContainer);