import React from 'react';
import PropTypes from 'prop-types';
import { Checkbox, Table  } from 'antd';
import { cx } from 'react-emotion';
import * as css from './TVSeasonStyle';
import TVEpisodeDetail from './TVEpisodeDetail';

const TVSeasonDetail = (props) => {
  return (
    <React.Fragment>
        {props.episodes.map(episode => {
          return (
            <TVEpisodeDetail 
              key={episode.id} 
              showId={props.showId}
              seasonId={props.seasonId}
              episode={episode} 
              updateDownloadedFlag={props.updateDownloadedFlag}
              updateWatchedFlag={props.updateWatchedFlag}
            />
          );
        })
      }
    </React.Fragment>
  );
};

TVSeasonDetail.propTypes = {
  showId: PropTypes.number,
  seasonId: PropTypes.number,
  episodes: PropTypes.array,
  updateDownloadedFlag: PropTypes.func,
  updateWatchedFlag: PropTypes.func,
};

export default TVSeasonDetail;