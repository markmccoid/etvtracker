import React from 'react';
import PropTypes from 'prop-types';
import { Collapse, Table, Checkbox } from 'antd';
import * as css from './TVSeasonStyle';

import TVSeasonDetail from './TVSeasonDetail';

const TVSeasonContainer = (props) => {
  const Panel = Collapse.Panel;
  if (!props.seasonData) {
    return null;
  }
// Function to deal with checkbox
  const onCheckboxChange = (reduxACFunction, showId, seasonEpisodeKeys, checkValue) => {
    // season and episode keys in string separated by ';'
    const [seasonId, episodeId ] = seasonEpisodeKeys.split(';');
    console.log('season.. keys', seasonId, episodeId);
    let payload = { showId, 
      seasonId, 
      episodeId, 
      checkboxState: checkValue
    };

    reduxACFunction(payload);
  };
// Setup table columns (antd)
  const columns = [{
    title: '#',
    dataIndex: 'num',
    key: 'num',
  }, {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
  }, {
    title: 'Air Date',
    dataIndex: 'airDate',
    key: 'airDate',
  }, {
    title: 'D',
    dataIndex: 'downloaded',
    key: 'downloaded',
    onHeaderCell: (column) => {
      return {
        onClick: () => {
          console.log('onClick', column);
        }
      };
    },
    render: (text, record, index) => <Checkbox onChange={(e) => 
        onCheckboxChange(props.updateDownloadedFlag, props.showId, record.key, e.target.checked)}
      >
      </Checkbox>
  }, {
    title: 'W',
    dataIndex: 'watched',
    key: 'watched',
    render: (text, record, index) => <Checkbox onChange={(e) => onCheckboxChange(props.updateWatchedFlag, props.showId, record.key, e.target.checked)}></Checkbox>
  }];

  return (
    <Collapse accordion className={css.seasonWrapper}>
      {props.seasonData.map(season => {
        let dataSource = season.episodes.map(episode => ({
            key: `${season.id};${episode.id}`,
            num: episode.number,
            name: episode.name,
            airDate: episode.airDate,
            downloaded: '',
            watched: ''
          }));
          return (
            <Panel header={season.name} key={season.id}>
              <TVSeasonDetail 
                showId={props.showId}
                seasonId={season.id}
                episodes={season.episodes} 
                updateDownloadedFlag={props.updateDownloadedFlag}
                updateWatchedFlag={props.updateWatchedFlag}                
              />
            </Panel>
          );
        })}
    </Collapse>
  );
};

TVSeasonContainer.propTypes = {
  seasonData: PropTypes.array,
  showId: PropTypes.number,
  updateDownloadedFlag: PropTypes.func,
  updateWatchedFlag: PropTypes.func,
};

export default TVSeasonContainer;


// antd Table
{/* <Collapse accordion className={css.seasonWrapper}>
{props.seasonData.map(season => {
  let dataSource = season.episodes.map(episode => ({
      key: `${season.id};${episode.id}`,
      num: episode.number,
      name: episode.name,
      airDate: episode.airDate,
      downloaded: '',
      watched: ''
    }));
    return (
        <Panel header={season.name} key={season.id} style={{ padding: "0px"}}>
          <Table 
            columns={columns} 
            dataSource={dataSource} 
            pagination={false}
            indentSize={0}
          />
        </Panel>
    );
  })}
</Collapse> */}