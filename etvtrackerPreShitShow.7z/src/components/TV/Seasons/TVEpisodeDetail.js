import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from 'antd';
import { cx } from 'react-emotion';
import * as css from './TVSeasonStyle';

const TVEpisodeDetail = (props) => {
  let { episode } = props;
  let updateObj = {
    showId: props.showId,
    seasonId: props.seasonId,
    episodeId: episode.id
  }
  
  return (
    <div className={css.episodeWrapper}>
      <div className={css.episodeNumber}>
        {episode.number}
      </div>
      <div className={css.episodeNameDateWrapper}>
        <div className={css.episodeName}>
          {episode.name}
        </div>
        <div>
          {episode.airDate}
        </div>
      </div>
      <div 
        className={cx(css.circle, episode.watched ? css.selected : null)}
        onClick={() => props.updateWatchedFlag({ ...updateObj, checkedState: !episode.watched })}
      >
        <Icon type="eye-o" />
      </div>
      <div 
        className={cx(css.circle, episode.downloaded ? css.selected : null)}
        onClick={() => props.updateDownloadedFlag({ ...updateObj, checkedState: !episode.downloaded })}
      >
        <Icon type="download" />
      </div>
    </div>
  );
};

TVEpisodeDetail.propTypes = {
  showId: PropTypes.number,
  seasonId: PropTypes.number,
  episode: PropTypes.object,
  updateDownloadedFlag: PropTypes.func,
  updateWatchedFlag: PropTypes.func,
};

export default TVEpisodeDetail;