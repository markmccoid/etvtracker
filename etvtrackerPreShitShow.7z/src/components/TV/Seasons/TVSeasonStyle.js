import { css } from 'react-emotion';

export const seasonWrapper = css`
  max-width: 800px;
  margin-right: 10px;
`;

// Episode CSS
export const episodeWrapper = css`
  display: flex;
  flex-direction: row;
  align-items: center;
  border-bottom: 1px solid #ccc;
  &:hover {
    background: #eee;
  }
  &:last-child {
    border-bottom: 0;
  }
`;

export const episodeNumber = css`
  font-size: 1.3em;
  width: 35px;
  margin: 5px;
`;

export const episodeNameDateWrapper = css`
  display: flex;
  flex-direction: column;
  width: 80%;
  margin: 5px;
`;

export const episodeName = css`
  font-weight: bold;
`;

export const circle = css`
  height: 25px;
  width: 25px;
  border: 1px solid #ccc;
  border-radius: 50%;
  margin-right: 10px;
  text-align: center;
  &:hover {
    background: lightgreen;
    cursor: pointer;
  }
`;

export const selected = css`
  background: green;
`;

// ------------------------------------
export const header = css`
  font-weight: bold;
`;

export const numWidth = css`
  width: 50px;
`;
export const nameWidth = css`
  width: 200px;
`;
export const dateWidth = css`
  width: 75px;
`;
export const checkboxWidth = css`
  width: 50px;
`;