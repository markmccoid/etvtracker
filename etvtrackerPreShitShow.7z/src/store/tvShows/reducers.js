import _ from 'lodash';
import { combineReducers } from 'redux';
import { handleActions } from 'redux-actions'

import {  SET_TV_SHOW_ERROR } from './actions';
import {  INIT_DATA, ADD_TV_SHOW, DELETE_TV_SHOW} from './actions';
import { findAndReadConfig } from '../../../node_modules/read-config-file';

// Shape of this reducer node:
// TV: {
//   showData: {},  //showDataReducer
//   seasonData: {},  //seasonDataReducer
//   extraData: {},  //extraDataReducer
//   errorData: {}, //errorDataReducer
// }

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// - showData reducer
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
const showDataDefault = {};

const showDataReducer = handleActions({
  INIT_DATA: (state, action) => {
    return action.payload.showData;
  },
  ADD_TV_SHOW: (state, action) => {
    return { ...state, [action.payload.showId]: action.payload.showObj.showData };
  },
  DELETE_TV_SHOW: (state, action) => {
    // filter removed the show object we want to delete, 
    // keyBy converts the array of objects returned by filter to an "Objects of Objects"
    return { ..._.keyBy(_.filter(state, (show) => show.showId !== action.payload), 'showId') }
  },
  AUTH_LOGOUT: (state, action) => {
    return {}; // clear TV Shows
  }
}, showDataDefault)

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// - seasonData reducer
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
const seasonDataDefault = {};

const seasonDataReducer = handleActions({
  INIT_DATA: (state, action) => {
    return action.payload.seasonData;
  },
  ADD_TV_SHOW: (state, action) => { 
    return { ...state, [action.payload.showId]: action.payload.showObj.seasonData };
  },
  DELETE_TV_SHOW: (state, action) => {
    // filter removed the show object we want to delete, 
    // keyBy converts the array of objects returned by filter to an "Objects of Objects"
    return { ..._.keyBy(_.filter(state, (show) => show.showId !== action.payload), 'showId') }
  },
  AUTH_LOGOUT: (state, action) => {
    return {}; // clear TV seasons
  },
}, seasonDataDefault);

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// - seasonData reducer
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
const userDataDefault = {};

const userDataReducer = handleActions({
  INIT_DATA: (state, action) => {
    return action.payload.userData;
  },
  ADD_TV_SHOW: (state, action) => { 
    return { ...state, [action.payload.showId]: action.payload.showObj.userData};
    //return { ...state, [action.payload.showId]: action.payload.showObj.userData };
  },
  DELETE_TV_SHOW: (state, action) => {
    console.log(state, action);
    // filter removed the show object we want to delete, 
    // keyBy converts the array of objects returned by filter to an "Objects of Objects"
    return { ..._.keyBy(_.filter(state, (show) => show.showId !== action.payload), 'showId') }
  },
  UPDATE_DOWNLOADED_FLAG: (state, action) => {
    // Update the download state action.payload = { showId, seasonId, EpisodeId, checkboxState }
    let { showId, seasonId, episodeId, checkedState } = action.payload;

    // get to the correct episode array for the showId and seasonId passed
    // Map through the array and find the episode to be updated and return a whole new episode array
    const newEpisodeArray = state[showId][seasonId].episodes.map((episode) => {
      if (episode.id === episodeId) {
        return {...episode, downloaded: checkedState };
      }
      return episode;
    });
    // Create a copy of state so we don't mutate 
    let newState = { ...state };
    // set the new episode array
    newState[showId][seasonId].episodes = newEpisodeArray;
  
    return newState;
  },
  UPDATE_WATCHED_FLAG: (state, action) => {
    // Same as the UPDATE_DOWNLOADED_FLAG -- should find a way to combine.
    // Update the watched state action.payload = { showId, seasonId, EpisodeId, checkboxState }
    let { showId, seasonId, episodeId, checkedState } = action.payload;

    // get to the correct episode array for the showId and seasonId passed
    // Map through the array and find the episode to be updated and return a whole new episode array
    const newEpisodeArray = state[showId][seasonId].episodes.map((episode) => {
      if (episode.id === episodeId) {
        return {...episode, watched: checkedState };
      }
      return episode;
    });
    // Create a copy of state so we don't mutate 
    let newState = { ...state };
    // set the new episode array
    newState[showId][seasonId].episodes = newEpisodeArray;

    return newState;
  },
  AUTH_LOGOUT: (state, action) => {
    return {}; // clear TV seasons
  },
}, userDataDefault);


// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// - extraData reducer
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
const extraDataDefault = {};

const extraDataReducer = handleActions({
  INIT_DATA: (state, action) => {
    return action.payload.extraData;
  },
  ADD_TV_SHOW: (state, action) => {
    return { ...state, [action.payload.showId]: action.payload.showObj.extraData };
  },
  DELETE_TV_SHOW: (state, action) => {
    // filter removed the show object we want to delete, 
    // keyBy converts the array of objects returned by filter to an "Objects of Objects"
    return { ..._.keyBy(_.filter(state, (show) => show.showId !== action.payload), 'showId') }
  },

  AUTH_LOGOUT: (state, action) => {
    return {}; // clear TV extra data
  },
}, extraDataDefault)

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// - error reducer
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
const errorDataDefault = {};

const errorDataReducer = (state = errorDataDefault, action) => {
  switch (action.type) {
    case SET_TV_SHOW_ERROR: 
      return { ...state, error: true, message: action.payload }
    default:
      // I'm sure this is not the best idea, but didn't want to clear error on all other calls
      // Will continute to look for a better way.  Obviously, this means that any other redux action 
      // will clear the error.
      return { ...state, error: false, message: undefined};
  }
}

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// - search reducer
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
const searchDataDefault = {};

const searchDataReducer = handleActions({
  SET_TV_SEARCHTERM: (state, action) => {
    return { ...state, searchTerm: action.payload }
  }
}, searchDataDefault)

const reducer = combineReducers({
  showData: showDataReducer,
  seasonData: seasonDataReducer,
  extraData: extraDataReducer,
  userData: userDataReducer,
  errorData: errorDataReducer,
  searchData: searchDataReducer
});

export default reducer;