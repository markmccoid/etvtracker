import _ from 'lodash';
import moment from 'moment';

/**
 * Returns data need for display of shows in sidebar
 * 
 * @param {object} showData - Object of showData as formatted in redux store
 * @param string searchTerm - Search string to filter return data by (show.name)
 * @returns {string[]} Returns an array of objects with needed show data
 */
export const getSidebarData = (showData, searchTerm = '') => {
  // create an array of shows
  let showArray = [];
  //pass the filtered showData (by searchTerm) as the object for lodash's map function.
  showArray = _.map(_.filter(showData, (showObj) => showObj.name.toLowerCase().includes(searchTerm)),
                   (showObj) => ({ id: showObj.showId, name: showObj.name }));
  return showArray || [];
};

/**
 * Returns all TVShowData in array format
 * 
 * @returns {string[]} Returns an array of objects with all tvshowdata
 */
export const getAllShowData = (showData) => {
  // create an array of shows
  let showArray = [];
  showArray = _.map(showData, (showObj) => ({ ...showObj }));
  return showArray || [];
};

/**
 * Returns on object with show data for the showId passed in
 * 
 * @param {number} showId - Id of show to return data for
 * @param {object} showData - Object of objects of showData as formatted in redux store
 * @returns {object} Returns an object of show data
 */
export const getCurrentShow = (showId, showData) => {
  // Create an object holding the passed show Ids data
  let currShow = {};
  currShow = showData[showId];
  // Format moment dates
  if (currShow) {
    currShow = { ...currShow, 
      firstAirDate: moment(currShow.firstAirDate).format("MM/DD/YYYY"),
      lastAirDate: moment(currShow.lastAirDate).format("MM/DD/YYYY"),
    }
  }
  return currShow || {};
}

/**
 * Returns an object with the season data for the showId passed in
 * 
 * @param {number} showId - Id of show to return data for
 * @param {object} seasonData - Object of objects seasonData as formatted in redux store
 * @returns {object} Returns an object of season data
 */
export const getCurrentSeasons = (showId, seasonData, userData) => {
  let currSeasons = {};
  currSeasons = seasonData[showId];
  // if no seasons, then return empty object
  if (!currSeasons) {
    return {};
  }
  
  //-- Start Load userData -----
  // FIRST Build the userData episode object 
  // Need to be VERY careful NOT to mutate state.  Since I am restructuring the data it mucks everything if you actually
  // mutate the redux state.
  let seasonUserDataTemp = { ...userData[showId] };
  let seasonUserData = {}
  // Looping through the season Ids and modify the episode array into an episode object with the episode id as the key
  // lodash's .keyBy does this for us.
  Object.keys(seasonUserDataTemp).forEach(seasonKey => {
    seasonUserData[seasonKey] = { ...seasonUserDataTemp[seasonKey] , episodes: { ..._.keyBy(seasonUserDataTemp[seasonKey].episodes, 'id') } }
  })
  //-- END Load userData -----
  // console.log('seasonUserData', seasonUserData);
  // return an array of seasons with an array of episodes embedded
  let newCurrSeasons = [];
  Object.keys(currSeasons).forEach(seasonKey => {
    let workingSeason = currSeasons[seasonKey];
    let workingUserSeason = seasonUserData[seasonKey];

    // showId is a key and doesn't have season info in it, so skip it
    if (seasonKey !== 'showId') {
      let episodes = [...workingSeason.episodes];
      let userEpisodes =  { ...workingUserSeason.episodes };

      let updEpisodes = [];
      //Loop through episodes and format date 
      // *** NOTE we are using Object.keys on an Array, we should change this.
      //  used to be that this was an object
      Object.keys(episodes).forEach(episodeKey => {
        updEpisodes.push({ ...episodes[episodeKey], 
          airDate: moment(episodes[episodeKey].airDate).format("MM/DD/YYYY"),
          downloaded: userEpisodes[episodes[episodeKey].id].downloaded,
          watched: userEpisodes[episodes[episodeKey].id].watched
        });
      });
      workingSeason= { ...workingSeason, episodes: _.sortBy(updEpisodes, ['number'])};
      // This is the old array based episodes
      // workingSeason.episodes = [ ...episodes.map(episode => 
      //     ({ ...episode, airDate: moment(episode.airDate).format("MM/DD/YYYY")}))];
      // Push the season on the array, formatting the season airdate as we do that.          
      newCurrSeasons.push({
        ...workingSeason, 
        airDate: moment(workingSeason.airDate).format("MM/DD/YYYY")
      });
    }
  });
  //console.log('selectors-seasons', newCurrSeasons)
  return _.sortBy(newCurrSeasons, ['number']);
}

/**
 * Returns an object with the userData for the showId passed in.  Will be in the format of
 * { 12332: { //Season ID
 *    55645:{ //Episode ID
 *      download: true/false
 *      watched: true/false
 *     },
 *    52333: { //Episode ID
 *      downloaded: true/false,
 *      watched: true/false
 *     },
 *    ...
 *   }
 * }
 * 
 * @param {number} showId - Id of show to return data for
 * @param {object} userData - Object of Season objects with Episode Array in each season userData as formatted in redux store
 * @returns {object} Returns an object of User data
 */
export const getUserEpisodeData = (showId, userData) => {
  // Need to be VERY careful NOT to mutate state.  Since I am restructuring the data it mucks everything if you actually
  // mutate the redux state.
  let seasonData = { ...userData[showId] };
  let seasonUserData = {}
  // Looping through the season Ids and modify the episode array into an episode object with the episode id as the key
  // lodash's .keyBy does this for us.
  Object.keys(seasonData).forEach(seasonKey => {
    seasonUserData[seasonKey] = { ...seasonData[seasonKey] , episodes: { ..._.keyBy(seasonData[seasonKey].episodes, 'id') } }
  })
  
  return seasonUserData;
}