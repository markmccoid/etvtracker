import { createActions, handleActions, combineActions } from 'redux-actions';
import { dmFetchTVShowData, dmGetInitialData, dmDeleteTVShow } from '../../dataModel';

// -- Init data Action Types
export const INIT_DATA = 'INIT_DATA';
// -- TV Show Action Types
export const ADD_TV_SHOW = 'ADD_TV_SHOW';
export const DELETE_TV_SHOW = 'DELETE_TV_SHOW';
export const SET_TV_SHOW_ERROR = 'SET_TV_SHOW_ERROR';
export const SET_TV_SEARCHTERM = 'SET_TV_SEARCHTERM';
export const UPDATE_DOWNLOADED_FLAG = 'UPDATE_DOWNLOADED_FLAG';
export const UPDATE_WATCHED_FLAG = 'UPDATE_WATCHED_FLAG';

// ************************************************
// - CREATE ACTION CREATORS
// ************************************************
export const {
  initData, // Passed the TVNode data
  addTvShow,
  deleteTvShow,
  setTvShowError,
  setTvSearchterm,
  updateDownloadedFlag,
  updateWatchedFlag
} = createActions(
  {},
    ADD_TV_SHOW,
    DELETE_TV_SHOW,
    INIT_DATA,
    SET_TV_SHOW_ERROR,
    SET_TV_SEARCHTERM,
    UPDATE_DOWNLOADED_FLAG,
    UPDATE_WATCHED_FLAG
  );
  
// ************************************************
// - THUNKS
// ************************************************
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// -- INITIALIZE DATA ( INIT_DATA )
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
export const startInitializeData = () => {
  return (dispatch, getState) => {
    let uid = getState().auth.uid;
    return dmGetInitialData(uid)
      .then((resp) => {
        dispatch(initData(resp));
      })
      .catch((err) => {
        console.log(`Error in startInitializeData: ${err}`);
      });
  };
};

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// -- ADD TV SHOW ( ADD_TV_SHOW )
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
export const startAddTVShow = (showId) => {
  return (dispatch, getState) => {
    let uid = getState().auth.uid;
    return dmFetchTVShowData(uid, showId)
      .then((showObj) => {
        dispatch(addTvShow({ showId, showObj }));
      })
      .catch((err) => {
        dispatch(setTvShowError({err, showId}))
      });
  };
};

// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// -- DELETE TV SHOW ( DELETE_TV_SHOW )
// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//export const deleteTVShow = (showId) => ({ type: DELETE_TV_SHOW, showId })
export const startDeleteTVShow = (showId) => {
  return (dispatch, getState) => {
    let uid = getState().auth.uid;
    return dmDeleteTVShow(uid, showId)
      .then(() => dispatch(deleteTvShow(showId)))
      .catch((err) => dispatch(deleteTvShow(err, showId)));
  };
};
