export const theme = {
  background: '#25274D',
  darkGray: '#464866',
  gray: '#AAABB8',
  lightBlue: '#2E9CCA',
  darkBlue: '#29648A'
}