import _ from 'lodash';
import { fb_readTVData } from '../firebase/firebaseInterface';

export const dmGetInitialData = async (uid) => {
  // Read TV node from firebase
  let TVNode = await fb_readTVData(uid);
  // Need to account for no data being returned
  // Should export a constant "INITIAL_STATE" variable from configureStore
  return TVNode || { showData: {}, seasonData: {}, extraData: {}, userData: {} };
}