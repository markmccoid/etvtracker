import _ from 'lodash';
import { getConfig, 
  getShowImages, 
  getShowDetails, 
  getEpisodes,
  getExternalIds } from '../api';
import { fb_UpdateTVShow, 
  fb_UpdateTVSeason, 
  fb_UpdateTVAll,
  fb_DeleteTVShow } from '../firebase/firebaseInterface';

import { formatDateStringForStorage } from '../utils/dates';



// -- Currently not using, but could be used to wrap async/await functions
// -- and catch their errors.
// -- export const dmFetchTVShowData = catchErrors(main_dmFetchTVShowData);
// function catchErrors(fn) {
//   return function (...arg) {
//     return fn(...arg).catch((err) => {
//       console.log(`Error in ${fn.name}.  Error: ${err}`);
//     });
//   };
// };

//--SYNCHRONOUS Image Functions --------------------------------------------------------------------
/**
 * Returns the full URL to an image.
 * 
 * @param {(string|string[])} imgFileName - file name of the image or Array of filenames.
 * @param {string} [size=m] - 's', *'m', 'l', 'original'.
 * @param {boolean} [secureURL=true] - return the https or http - *true
 * @returns {string[]} full URL to the image 
 */
export const getImageURLSync = (imgFileName, size = 'm', secureURL=true) => {
  
  // Hardcoding s, m, l for now
  switch (size) {
    case 's': 
      size = 'w185';
      break;
    case 'm': 
      size = 'w300';
      break;      
    case 'l': 
      size = 'w500';
      break;
    case 'original': 
      size = 'original';
      break;
    default:
      size = 'w300';
  }
  let baseURL = secureURL ? 'https://image.tmdb.org/t/p/' : 'http://image.tmdb.org/t/p/';
  // Get rid of any preceding '/'  in the passed imgFileName
  let regEx = /[^\/].*/;
  // If imgFileName IS NOT an array, then process as single file, but still return array
  if (!Array.isArray(imgFileName)) {
    return imgFileName ? [`${baseURL}${size}/${imgFileName.match(regEx)[0]}`] : [''];
  }
  // Process as an array and return an array, also make sure some value exists in each array slot.
  return imgFileName.map(file => file ? `${baseURL}${size}/${file.match(regEx)[0]}` : '');
};

/**
 * Returns an array of image URLs. Filters and gives only 'en' English images
 * 
 * @param {(string)} showId - showId from TMDb API Show Search.
 * @param {string} [imageType=posters] - *'posters', 'backdrops'
 * @returns {string[]} Array of URLs to the images
 */
export const getImagesForShowSync = (showId, imageType = 'posters') => {
  return getShowImages(showId)
    .then((resp) => {
      // Get array of file_paths
      let imgFilePaths = resp.data[imageType].filter((imgObj) => imgObj.iso_639_1 === 'en')
        .map((imgObj) => {
        return imgObj.file_path;
      });
      // Get the full image URLs
      return getImageURLSync(imgFilePaths, 'm', true);
    });
};
//----------------------------------------------------------------------

/**
 * Returns the full URL to an image.
 * 
 * @param {(string|string[])} imgFileName - file name of the image or Array of filenames.
 * @param {string} [size=m] - 's', *'m', 'l', 'original'.
 * @param {boolean} [secureURL=true] - return the https or http - *true
 * @returns {string[]} full URL to the image
 */
export const getImageURL = async (imgFileName, size = 'm', secureURL=true) => {
  // Hardcoding s, m, l for now
  switch (size) {
    case 's': 
      size = 'w185';
      break;
    case 'm': 
      size = 'w300';
      break;      
    case 'l': 
      size = 'w500';
      break;
    case 'original': 
      size = 'original';
      break;
    default:
      size = 'w300';
  }
  let baseURL;
  let resp = await getConfig();
  // Get rid of any preceding '/'  in the passed imgFileName
  let regEx = /[^\/].*/;
  baseURL = resp.data.images[secureURL ? 'secure_base_url' : 'base_url'];
  // If imgFileName IS NOT an array, then process as single file, but still return array
  if (!Array.isArray(imgFileName)) {
    return imgFileName ? [`${baseURL}${size}/${imgFileName.match(regEx)[0]}`] : [''];
  }
  // Process as an array and return an array, also make sure some value exists in each array slot.
  return imgFileName.map(file => file ? `${baseURL}${size}/${file.match(regEx)[0]}` : '');
};

/**
 * Returns an array of image URLs. Filters and gives only 'en' English images
 * 
 * @param {(string)} showId - showId from TMDb API Show Search.
 * @param {string} [imageType=posters] - *'posters', 'backdrops'
 * @returns {string[]} Array of URLs to the images
 */
export const getImagesForShow = (showId, imageType = 'posters') => {
  return getShowImages(showId)
    .then((resp) => {
      // Get array of file_paths
      let imgFilePaths = resp.data[imageType].filter((imgObj) => imgObj.iso_639_1 === 'en')
        .map((imgObj) => {
        return imgObj.file_path;
      });
      // Get the full image URLs
      return getImageURL(imgFilePaths, 'm', true);
    });
};

/**
 * @typedef {Object} TV
 * @property {Object} tvShow Primary data for a tvShow
 * @property {Object} seasonData The season data for the tv show (Object Key)
 * @property {Object} extraData Additional data for the tv show (Object Key)
 */
/**
 * First retrieves data from TMDb API and stores in Firebase
 * Then format the data and returns and object for the reducer to store in redux
 * Returns an object of objects -> tvShow: {}, seasonData: {}, extraData: {}
 * 
 * @param {(string)} showId - showId from TMDb API Show Search.
 * @returns {TV} TV Object
 */
export const dmFetchTVShowData = async (uid, showId) => {
  let resp = await getShowDetails(showId);
  let respShowData = resp.data; 
  // Format and hydrate showData
  let images = getImageURLSync([respShowData.backdrop_path, respShowData.poster_path], 'm', true);
  let genres = respShowData.genres.map(genre => genre.name)
  let showData = {
    showId: showId,
    name: respShowData.name,
    backdropPath: images[0],
    posterPath: images[1],
    status: respShowData.status,
    genres,
    firstAirDate: formatDateStringForStorage(respShowData.first_air_date),
    lastAirDate: formatDateStringForStorage(respShowData.last_air_date),
    totalEpisodes: respShowData.number_of_episodes,
    totalSeasons: respShowData.number_of_seasons,
    overview: respShowData.overview
  };
  // Format and hydrate season data
  let seasonData = await createSeasonData(showId, respShowData.seasons);
  // Build userData
  let userData = buildUserData(showId, seasonData);
  // Format and hydrate extraData
  let extraData = await createExtraData(showId, showData.name);
  // Build showObj that will be returned.
  let showObj = { showData, seasonData, userData, extraData }
  // Add show object to Firebase
  await fb_UpdateTVAll(uid, showId, showObj);
  
  return showObj;
};

/**
 * Part of the dmFetchTVShowData functions actions
 * takes the array of seasons and returns formatted object with 
 * seasons and episode data for each season
 * Returns an object -> { name: , ... episodes: {}}
 * 
 * @param {(string)} showId - showId from TMDb API Show Search.
 * @param {object[]} season array
 * @returns {object} seasonsObj
 */
const createSeasonData = async (showId, seasons) => {
  // create an array of season but exclude any season_number = 0
  let seasonArray = await Promise.all(seasons.filter((season) => season.season_number !== 0)
    .map(async (season, idx) => {
      return await createSeasonEpisodeData(showId, idx+1);
    })
    );
   
    // Prepending an S for each season number in key
    // This is because of firebase's behaviour of treating any integer keys as arrays
    // It would return an array, so this is making it return an object
    // BUT instead decided to use the season id as the object key
    let seasonsObj = {
      showId: showId,
    };
    seasonArray.forEach((season) => {
      seasonsObj = {
        ...seasonsObj,
        [`${season.id}`]: season
      };
    });
  return seasonsObj;
};

const createSeasonEpisodeData = async (showId, seasonNum) => {
  let resp = await getEpisodes(showId, seasonNum);
  let seasonObj = resp.data;
  let episodeArray = seasonObj.episodes;
  let posterImage = getImageURLSync(seasonObj.poster_path, 'm', true);
  let episodes = await formatEpisodes(episodeArray);

  return {
    id: seasonObj.id,
    number: seasonObj.season_number,
    name: seasonObj.name,
    airDate: formatDateStringForStorage(seasonObj.air_date),
    overview: seasonObj.overview,
    posterPath: posterImage[0],
    episodes: episodes
  };
};

const formatEpisodes = (episodeArray) => {
  return episodeArray.map((episode) => {
      return {
        id: episode.id,
        number: episode.episode_number,
        airDate: formatDateStringForStorage(episode.air_date),
        name: episode.name,
        stillPath: getImageURLSync(episode.still_path, 'm', true)[0], 
        overview: episode.overview
      };
    });

  // let finalEpisodeObj;
// -The below was used to create an object with episode IDs as the keys
// -going back to just and array of objects
  // episodeWork.forEach((episode) => {
  //   finalEpisodeObj = {
  //     ...finalEpisodeObj,
  //     [episode.id]: { ...episode }
  //   }
  // });
  // console.log('finalEpObj', finalEpisodeObj);
  // return finalEpisodeObj;
};

const buildUserData = (showId, seasonData) => {
  console.log('seasonData', seasonData)
  let seasonArray = Object.keys(seasonData).filter(key => key !== 'showId').map((season, idx) => {
    if (season === 'showId') { return null }
    let userEpisodes = seasonData[season].episodes.map(episode => ({ id: episode.id, downloaded: false, watched: false }))
    
    return {
      id: seasonData[season].id,
      // Create episode array 
      episodes: userEpisodes
    }
  });
  // this is because of showId gets a null array row. Need to find a better way.
  //seasonArray.pop();
  
  let seasonUserObj = {
    showId: showId,
  };
  seasonArray.forEach(season => {
    seasonUserObj = { ...seasonUserObj, [season.id]: { episodes: season.episodes }}
  });
  console.log('seasonUserObj', seasonUserObj)
  return seasonUserObj;
}

const createExtraData = async (showId, showName) => {
  let { data: extData } = await getExternalIds(showId);
  let externalIds = {
    imdbId: extData.imdb_id,
    tvRageId: extData.tvrage_id
  };
  let links = {
    imdbLink: {
      linkDescription: 'IMDB Link',
      link: `http://www.imdb.com/title/${extData.imdb_id}`,
    },
  };
  return {
    showId: showId,
    externalIds,
    links
  }
};

export const dmDeleteTVShow = async (uid, showId) => {
  await fb_DeleteTVShow(uid, showId);
};